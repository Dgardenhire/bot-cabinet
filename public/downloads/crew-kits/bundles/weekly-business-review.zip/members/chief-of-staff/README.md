# Chief of Staff — Executive priority and coordination assistant

Keeps a leader's confirmed priorities, decisions, responsibilities and follow-ups in one current summary.

This is a Bot Cabinet Portable Bot Pack V2 Hermes profile archive. Review every file before importing it or granting access.

## Package status

- The generated files and archive structure are checked at build time.
- This V2 archive passed an isolated import with Hermes Agent 0.21.0 on 2026-09-04.
- That import test confirmed the archive and bundled Skill were present. It did not test output quality or live-service behavior.
- The included Skill is prepared and not-tested.
- The Routine is a plan only: manual-test-required and not-tested.
- No schedule or active Routine is included in this package.

## Set it up

1. Review SOUL.md, BOT-PASSPORT.md, and the included Skill.
2. Import the profile archive only after its role and controls match your intended job.
3. Select only the tools and connections required for the job.
4. Run this first mission with sample material: Use sample updates from two projects to produce a one-page priority brief and a decision log for review.
5. Review the result at the human checkpoint before adding authority or activating a Routine.

Portable source: https://botcabinet.com/downloads/portable-bot-packs/v2/chief-of-staff.md
