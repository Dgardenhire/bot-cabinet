# Ops — Operations monitoring assistant

Checks a defined set of systems or scheduled tasks and reports missed runs, failures, and unusual changes.

This is a Bot Cabinet Portable Bot Pack V2 Hermes profile archive. Review every file before importing it or granting access.

## Package status

- The generated files and archive structure are checked at build time.
- This V2 archive passed an isolated import with Hermes Agent 0.21.0 on 2026-09-04.
- That import test confirmed the archive and bundled Skill were present. It did not test output quality or live-service behavior.
- The included Skill “Ops core Skill” is prepared and not-tested.
- The included Skill “Diagnose a bad AI result” is prepared and not-tested.
- The Diagnose a bad AI result Skill is based on the public Diagnose My Agent's Mistake listing on Muse at Work, which does not name its creator: https://museatwork.app/#w=1d0661a5-1cf7-4013-9aff-9cf605bcbe8c
- The Routine is a plan only: manual-test-required and not-tested.
- No schedule or active Routine is included in this package.

## Set it up

1. Review SOUL.md, BOT-PASSPORT.md, and every included Skill.
2. Import the profile archive only after its role and controls match your intended job.
3. Select only the tools and connections required for the job.
4. Run this first mission with sample material: Check two harmless status sources and produce a report without changing either system.
5. Review the result at the human checkpoint before adding authority or activating a Routine.

Portable source: https://botcabinet.com/downloads/portable-bot-packs/v2/ops.md
